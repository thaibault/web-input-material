import { WebComponentAPI } from 'web-component-wrapper/type';
export declare const RequireableCheckbox: WebComponentAPI;
export default RequireableCheckbox;
