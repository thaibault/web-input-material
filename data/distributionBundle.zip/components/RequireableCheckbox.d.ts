import Checkbox from 'react-input-material/dist/components/RequireableCheckbox';
import { WebComponentAPI } from 'web-component-wrapper/type';
export declare const RequireableCheckbox: WebComponentAPI<typeof Checkbox>;
export default RequireableCheckbox;
