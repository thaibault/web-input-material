import ReactFileInput from 'react-input-material/components/FileInput';
import { WebComponentAPI } from 'web-component-wrapper/type';
export declare const FileInput: WebComponentAPI<typeof ReactFileInput>;
export default FileInput;
