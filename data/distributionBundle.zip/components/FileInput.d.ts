import { WebComponentAPI } from 'web-component-wrapper/type';
export declare const FileInput: WebComponentAPI;
export default FileInput;
