import { WebComponentAPI } from 'web-component-wrapper/type';
export declare const GenericAnimate: WebComponentAPI;
export default GenericAnimate;
