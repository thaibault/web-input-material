import ReactGenericAnimate from 'react-input-material/dist/components/GenericAnimate';
import { WebComponentAPI } from 'web-component-wrapper/type';
export declare const GenericAnimate: WebComponentAPI<typeof ReactGenericAnimate>;
export default GenericAnimate;
