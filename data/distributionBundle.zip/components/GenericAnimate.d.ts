import ReactGenericAnimate from 'react-generic-animate';
import { WebComponentAPI } from 'web-component-wrapper/type';
export declare const GenericAnimate: WebComponentAPI<typeof ReactGenericAnimate>;
export default GenericAnimate;
