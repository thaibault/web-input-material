import ReactTextInput from 'react-input-material/dist/components/TextInput';
import { WebComponentAPI } from 'web-component-wrapper/type';
export declare const TextInput: WebComponentAPI<typeof ReactTextInput>;
export default TextInput;
