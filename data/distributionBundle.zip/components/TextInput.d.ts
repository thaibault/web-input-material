import ReactTextInput from 'react-input-material/components/TextInput';
import { WebComponentAPI } from 'web-component-wrapper/type';
export declare const TextInput: WebComponentAPI<typeof ReactTextInput>;
export default TextInput;
