import Interval from 'react-input-material/components/Interval';
import { WebComponentAPI } from 'web-component-wrapper/type';
export declare const IntervalInput: WebComponentAPI<typeof Interval>;
export default IntervalInput;
