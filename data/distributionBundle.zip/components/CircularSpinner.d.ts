import { WebComponentAPI } from 'web-component-wrapper/type';
export declare const CircularSpinner: WebComponentAPI;
export default CircularSpinner;
