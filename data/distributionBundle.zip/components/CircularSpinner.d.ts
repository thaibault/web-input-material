import { WebComponentAPI } from 'web-component-wrapper/type';
import { CircularProgress } from '@rmwc/circular-progress';
export declare const CircularSpinner: WebComponentAPI<typeof CircularProgress>;
export default CircularSpinner;
