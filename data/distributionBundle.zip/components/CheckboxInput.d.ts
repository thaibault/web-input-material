import Checkbox from 'react-input-material/components/Checkbox';
import { WebComponentAPI } from 'web-component-wrapper/type';
export declare const CheckboxInput: WebComponentAPI<typeof Checkbox>;
export default CheckboxInput;
