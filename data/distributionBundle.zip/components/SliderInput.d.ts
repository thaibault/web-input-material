import { Mapping } from 'clientnode/type';
import { WebComponentAPI } from 'web-component-wrapper/type';
export interface Properties extends Mapping<unknown> {
    disabled: boolean;
    discrete: boolean;
    displayMarkers: boolean;
    max: number;
    min: number;
    step: number;
    value: number;
}
export declare const SliderInput: WebComponentAPI;
export default SliderInput;
