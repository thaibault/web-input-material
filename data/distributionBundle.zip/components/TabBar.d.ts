import { WebComponentAPI } from 'web-component-wrapper/type';
export declare const TabBar: WebComponentAPI;
export default TabBar;
