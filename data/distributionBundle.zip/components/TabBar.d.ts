import { WebComponentAPI } from 'web-component-wrapper/type';
import { TabBar as ReactTabBar } from '@rmwc/tabs';
export declare const TabBar: WebComponentAPI<typeof ReactTabBar>;
export default TabBar;
