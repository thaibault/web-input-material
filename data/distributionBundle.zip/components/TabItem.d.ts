import { WebComponentAPI } from 'web-component-wrapper/type';
import { Tab } from '@rmwc/tabs';
export declare const TabItem: WebComponentAPI<typeof Tab>;
export default TabItem;
