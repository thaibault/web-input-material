import { WebComponentAPI } from 'web-component-wrapper/type';
export declare const TabItem: WebComponentAPI;
export default TabItem;
