import { WebComponentAPI } from 'web-component-wrapper/type';
export declare const GenericInterval: WebComponentAPI;
export default GenericInterval;
