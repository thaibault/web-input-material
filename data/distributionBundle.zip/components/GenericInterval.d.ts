import Interval from 'react-input-material/dist/components/Interval';
import { WebComponentAPI } from 'web-component-wrapper/type';
export declare const GenericInterval: WebComponentAPI<typeof Interval>;
export default GenericInterval;
