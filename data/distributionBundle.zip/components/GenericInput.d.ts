import ReactGenericInput from 'react-input-material/dist/components/GenericInput';
import { WebComponentAPI } from 'web-component-wrapper/type';
export declare const GenericInput: WebComponentAPI<typeof ReactGenericInput>;
export default GenericInput;
