import { WebComponentAPI } from 'web-component-wrapper/type';
export declare const GenericInput: WebComponentAPI;
export default GenericInput;
