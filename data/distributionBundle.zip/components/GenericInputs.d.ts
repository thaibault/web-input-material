import { WebComponentAPI } from 'web-component-wrapper/type';
export declare const GenericInputs: WebComponentAPI;
export default GenericInputs;
