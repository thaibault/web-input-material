import ReactInputs from 'react-input-material/components/Inputs';
import { WebComponentAPI } from 'web-component-wrapper/type';
export declare const GenericInputs: WebComponentAPI<typeof ReactInputs>;
export default GenericInputs;
