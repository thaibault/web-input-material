export type { BaseModel, CommonBaseModel, BaseProperties, BaseProps, Properties, Props, TypedProperties, DefaultBaseProperties, DefaultProperties, ModelState, EditorState, State, ValueState, StaticComponent, StaticFunctionComponent, StaticWebComponent } from 'react-input-material/dist/type';
export type { GenericEvent } from 'react-generic-tools/type';
