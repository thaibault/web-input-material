export type { BaseModel, CommonBaseModel, BaseProperties, BaseProps, Properties, Props, TypedProperties, DefaultBaseProperties, DefaultProperties, ModelState, State, ValueState, StaticComponent, StaticFunctionComponent, StaticWebComponent } from 'react-input-material/type';
export type { GenericEvent } from 'react-generic-tools/type';
