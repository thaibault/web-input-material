// -*- coding: utf-8 -*-
/** @module declarations */
/// <reference path="node_modules/weboptimizer/declarations" />
// region vim modline
// vim: set tabstop=4 shiftwidth=4 expandtab:
// vim: foldmethod=marker foldmarker=region,endregion:
// endregion
